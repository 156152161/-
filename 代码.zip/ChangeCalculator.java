package org.example;

import javax.swing.*;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

public class ChangeCalculator {

    public static void main(String[] args) {

        // 创建主窗口

        JFrame frame = new JFrame("找零计算器");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setSize(400, 200);

        // 创建面板

        JPanel panel = new JPanel();

        frame.add(panel);

        placeComponents(panel);

        // 设置窗口可见

        frame.setVisible(true);

    }

    private static void placeComponents(JPanel panel) {

        panel.setLayout(null);

        // 创建标签和文本框

        JLabel priceLabel = new JLabel("请输入商品价格（1-100元）：");

        priceLabel.setBounds(10, 20, 300, 25);

        panel.add(priceLabel);

        JTextField priceInput = new JTextField(20);

        priceInput.setBounds(10, 50, 165, 25);

        panel.add(priceInput);

        JLabel paymentLabel = new JLabel("请输入付款金额（1-100元）：");

        paymentLabel.setBounds(10, 80, 300, 25);

        panel.add(paymentLabel);

        JTextField paymentInput = new JTextField(20);

        paymentInput.setBounds(10, 110, 165, 25);

        panel.add(paymentInput);

        // 创建按钮

        JButton btnCalculate = new JButton("计算找零");

        btnCalculate.setBounds(190, 50, 100, 25);

        panel.add(btnCalculate);

        JButton btnReset = new JButton("重置");

        btnReset.setBounds(190, 110, 100, 25);

        panel.add(btnReset);

        // 创建标签用于显示结果

        JLabel resultLabel = new JLabel();

        resultLabel.setBounds(10, 140, 370, 25);

        panel.add(resultLabel);

        // 添加按钮点击事件

        btnCalculate.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                try {

                    int R = Integer.parseInt(priceInput.getText());

                    int P = Integer.parseInt(paymentInput.getText());

                    String result = calculateChange(R, P);

                    resultLabel.setText(result);

                } catch (NumberFormatException ex) {

                    resultLabel.setText("无效输入：请输入整数");

                }

            }

        });

        btnReset.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                priceInput.setText("");

                paymentInput.setText("");

                resultLabel.setText("");

            }

        });

    }

    private static String calculateChange(int R, int P) {

        // 检查输入是否有效

        if (R <= 0 || P <= 0 || R > 100 || P > 100 || P < R) {

            return "无效输入：价格和付款必须为整数且在1-100元之间，付款金额不能小于价格";

        }

        // 计算找零金额

        int C = P - R;

        if (C == 0) {

            return "无需找零";

        }

        // 计算最佳找零组合

        int N50 = C / 50;

        C %= 50;

        int N10 = C / 10;

        C %= 10;

        int N5 = C / 5;

        C %= 5;

        int N1 = C;

        return String.format("找零组合：%d 张 50 元，%d 张 10 元，%d 张 5 元，%d 张 1 元", N50, N10, N5, N1);

    }

}

